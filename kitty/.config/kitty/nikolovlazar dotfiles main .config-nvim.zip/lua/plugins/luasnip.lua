return {
  "L3MON4D3/LuaSnip",
  opts = {
    history = true,
    region_check_events = "InsertEnter",
    delete_check_events = "TextChanged,InsertLeave",
  },
}
