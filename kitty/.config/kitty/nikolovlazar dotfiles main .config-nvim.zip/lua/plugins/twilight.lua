return {
  "folke/twilight.nvim",
  opts = {
    context = 0,
    expand = {
      "function",
      "method",
      "table",
      "if_statement",
      "function_declaration",
      "method_declaration",
      "pair",
    },
  },
}
