return {
  "smjonas/inc-rename.nvim",
  cmd = "IncRename",
  config = true,
}
