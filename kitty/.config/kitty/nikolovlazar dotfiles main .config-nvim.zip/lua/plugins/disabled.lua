return {
  -- Disable auto opening (){}[]
  { "echasnovski/mini.pairs", enabled = false },
}
