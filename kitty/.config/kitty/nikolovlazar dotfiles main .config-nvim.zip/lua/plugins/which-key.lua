return {
  {
    "folke/which-key.nvim",
    opts = {
      spec = {
        { "<leader>cp", group = "packages", icon = { icon = "", color = "yellow" } },
      },
    },
  },
}
